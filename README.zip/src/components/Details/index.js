import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import List from '../Cards/List'
import Loader from '../Loader'
import axios from 'axios'

function Details() {
  const {id} = useParams()
  const [fetchedData,setFetchedData] = useState({
    loading : true,
    data : [],
    error : ''
  });
  console.log(fetchedData)
  const [coinDetails,setCoinDetails] = useState({})

  console.log(coinDetails)

  const filterFetchedData = () => {
    setCoinDetails({
      id : fetchedData.data.id,
      symbol : fetchedData.data.symbol,
      name : fetchedData.data.name,
      // image : fetchedData.data.image.large,
      // price_change_percentage_24h : fetchedData.data.market_data.price_change_percentage_24h,
      // current_price : fetchedData.data.market_data.current_price.usd,
      // total_volume : fetchedData.data.market_data.total_volume.usd,
      // market_cap : fetchedData.data.market_data.market_cap.usd
    })
  }

  console.log(fetchedData)
  useEffect(() => {
    if(id) {
      axios.get(`https://api.coingecko.com/api/v3/coins/${id}`)
      .then((response) => setFetchedData({loading: false,data:response.data,error:''}))
      .catch((error) => setFetchedData({loading: false,data:[],error:error.message}))
    }
    filterFetchedData()
  },[id])

  return (
    <div>
      {fetchedData.loading?<Loader/> :
      <>
      {/* <List coins={coinDetails}/> */}
      
      </>
      }

    </div>
  )
}

export default Details